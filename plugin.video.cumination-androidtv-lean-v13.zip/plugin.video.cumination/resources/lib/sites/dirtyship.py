"""
    Cumination
    Copyright (C) 2026 Team Cumination
"""

import json
import re
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite('dirtyship', '[COLOR hotpink]DirtyShip[/COLOR]', 'https://dirtyship.com/', 'https://dirtyship.com/favicon.ico', 'dirtyship')


def _rest_categories(page=1):
    url = '{}wp-json/wp/v2/categories?per_page=100&page={}&_fields=id,count,name,slug,link'.format(site.url, page)
    data = utils.getHtml(url, site.url)
    try:
        return json.loads(data)
    except Exception:
        return []


def _next_page(html):
    matches = re.findall(r'rel="next" href="([^"]+)"', html, re.IGNORECASE)
    if not matches:
        return None
    next_page = matches[-1]
    if next_page.startswith('//'):
        next_page = 'https:' + next_page
    return next_page


def _get_performers(url):
    lookup_list = [
        ("Performer", r'href="(https://dirtyship\.com/performer/[^"]+/)" title="([^"]+)">', ''),
    ]
    lookupinfo = utils.LookupInfo('', url, 'dirtyship.List', lookup_list)
    return lookupinfo.getitems(labels=utils.PERFORMER_TYPES)


def _performer_action(url, action):
    performer = utils.select_performer(_get_performers(url))
    if not performer:
        utils.notify('Notify', 'No model found for this video')
        return
    if action == 'profile':
        utils.container_update('dirtyship.List', url=performer['url'])
    elif action == 'search':
        utils.container_update('dirtyship.Search', url=site.url + '?s=', keyword=performer['name'])
    else:
        utils.add_keyword_direct(performer['name'])


def _gallery_images(url, html):
    slug = url.rstrip('/').rsplit('/', 1)[-1]
    slug_tokens = {token for token in re.split(r'[^a-z0-9]+', slug.lower()) if len(token) > 2}
    matches = re.findall(r'https://dirtyship\.com/wp-content/uploads/[^\s,"\']+\.(?:jpg|jpeg|png)', html, re.IGNORECASE)
    cleaned = []
    seen = set()
    for img in matches:
        normalized = re.sub(r'-(\d+)x(\d+)(\.(?:jpg|jpeg|png))$', r'\3', img, flags=re.IGNORECASE)
        basename = normalized.rsplit('/', 1)[-1].lower()
        if basename.startswith('hd-'):
            continue
        token_hits = sum(1 for token in slug_tokens if token in basename)
        if slug_tokens and token_hits < 2:
            continue
        if normalized in seen:
            continue
        seen.add(normalized)
        cleaned.append(normalized)
    return cleaned


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Latest Videos[/COLOR]', site.url, 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', '', 'Categories', site.img_cat, page=1)
    site.add_dir('[COLOR hotpink]Performers[/COLOR]', site.url + 'actors-4/', 'Performers', site.img_cat)
    site.add_dir('[COLOR hotpink]Photos[/COLOR]', site.url + 'phototype/onlyfansss/', 'Photos', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + '?s=', 'Search', site.img_search)
    List(site.url)


@site.register()
def List(url):
    html = utils.getHtml(url, site.url)
    matches = re.findall(
        r'<li class="thumi"><a href="([^"]+)"[^>]*title="([^"]+)"><img src="([^"]+)"[^>]*alt="([^"]+)".*?<span class="post-category"><a href="([^"]+)">([^<]+)</a>',
        html, re.DOTALL | re.IGNORECASE)
    for videopage, title, img, alt_name, caturl, catname in matches:
        name = utils.cleantext(title or alt_name)
        desc = utils.cleantext(catname)
        contextm = utils.performer_context_menu(site.module_name, videopage)
        site.add_download_link(name, videopage, 'Playvid', img, desc, noDownload=True, contextm=contextm)
    next_page = _next_page(html)
    if next_page:
        site.add_dir('Next Page...', next_page, 'List', site.img_next)
    utils.eod()


@site.register()
def Categories(url=None, page=1):
    for item in _rest_categories(page):
        if item.get('count', 0) < 1:
            continue
        site.add_dir('{} [COLOR deeppink]{}[/COLOR]'.format(item['name'], item['count']), item['link'], 'List', '')
    if len(_rest_categories(page + 1)) > 0:
        site.add_dir('Next Page ({})'.format(page + 1), '', 'Categories', site.img_next, page=page + 1)
    utils.eod()


@site.register()
def Performers(url):
    html = utils.getHtml(url, site.url)
    matches = re.findall(r'<a class="outline" href="([^"]+)" title="([^"]+)">\s*<img src="([^"]+)"', html, re.DOTALL | re.IGNORECASE)
    for performer_url, name, img in matches:
        site.add_dir(utils.cleantext(name), performer_url, 'List', img)
    next_page = _next_page(html)
    if next_page:
        site.add_dir('Next Page...', next_page, 'Performers', site.img_next)
    utils.eod()


@site.register()
def Photos(url):
    html = utils.getHtml(url, site.url)
    matches = re.findall(r'href="(https://dirtyship\.com/phototype/[^"]+/)"[^>]*>([^<]+)<', html, re.IGNORECASE)
    seen = set()
    for phototype_url, name in matches:
        name = utils.cleantext(name)
        if not name or phototype_url in seen:
            continue
        seen.add(phototype_url)
        site.add_dir(name, phototype_url, 'PhotoList', '')
    utils.eod()


@site.register()
def PhotoList(url):
    html = utils.getHtml(url, site.url)
    matches = re.findall(r'<li class="thumbphoto"><a href="([^"]+)" title="([^"]+)"><img src="([^"]+)"', html, re.DOTALL | re.IGNORECASE)
    for gallery_url, name, img in matches:
        site.add_dir(utils.cleantext(name), gallery_url, 'PhotoGallery', img)
    next_page = _next_page(html)
    if next_page:
        site.add_dir('Next Page...', next_page, 'PhotoList', site.img_next)
    utils.eod()


@site.register()
def PhotoGallery(url):
    html = utils.getHtml(url, site.url)
    for img in _gallery_images(url, html):
        site.add_img_link(img.rsplit('/', 1)[-1], img, 'Showpic')
    utils.eod()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        List(url + urllib_parse.quote_plus(keyword))


@site.register()
def Playvid(url, name, download=None):
    html = utils.getHtml(url, site.url)
    matches = re.findall(r'<source title="([^"]+)" src=([^\s>]+) type="video/mp4"', html, re.IGNORECASE)
    if not matches:
        utils.notify('Oh oh', 'No video found')
        return
    videourl = max(matches, key=lambda item: int(re.sub(r'\D', '', item[0]) or 0))[1]
    utils.playvid(videourl, name, download=download)


@site.register()
def Lookupinfo(url):
    lookup_list = [
        ("Performer", r'href="(https://dirtyship\.com/performer/[^"]+/)" title="([^"]+)">', ''),
        ("Category", r'href="(https://dirtyship\.com/category/[^"]+/)"[^>]*>([^<]+)<', ''),
    ]
    lookupinfo = utils.LookupInfo('', url, 'dirtyship.List', lookup_list)
    lookupinfo.getinfo()


@site.register()
def OpenModelProfile(url):
    _performer_action(url, 'profile')


@site.register()
def SearchModel(url):
    _performer_action(url, 'search')


@site.register()
def SaveModel(url):
    _performer_action(url, 'save')


@site.register()
def Showpic(url):
    utils.showimage(url)
