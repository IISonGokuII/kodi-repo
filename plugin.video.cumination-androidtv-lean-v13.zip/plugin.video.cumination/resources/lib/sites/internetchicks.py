"""
    Cumination
    Copyright (C) 2026 Team Cumination
"""

import json
import re
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite('internetchicks', '[COLOR hotpink]Internet Chicks[/COLOR]', 'https://internetchicks.com/', 'https://internetchicks.com/favicon.ico', 'internetchicks')


def _rest_terms(endpoint, page=1):
    url = '{}wp-json/wp/v2/{}?per_page=100&page={}&_fields=id,count,name,slug,link'.format(site.url, endpoint, page)
    data = utils.getHtml(url, site.url)
    try:
        return json.loads(data)
    except Exception:
        return []


def _get_performers(url):
    lookup_list = [
        ("Actress", r'href="(https://internetchicks\.com/actress/[^"]+/)"[^>]*>([^<]+)<', ''),
    ]
    lookupinfo = utils.LookupInfo('', url, 'internetchicks.List', lookup_list)
    return lookupinfo.getitems(labels=utils.PERFORMER_TYPES)


def _performer_action(url, action):
    performer = utils.select_performer(_get_performers(url))
    if not performer:
        utils.notify('Notify', 'No model found for this video')
        return
    if action == 'profile':
        utils.container_update('internetchicks.List', url=performer['url'])
    elif action == 'search':
        utils.container_update('internetchicks.Search', url=site.url + '?s=', keyword=performer['name'])
    else:
        utils.add_keyword_direct(performer['name'])


def _next_page(html):
    match = re.search(r'rel="next" href="([^"]+)"', html, re.IGNORECASE)
    return match.group(1) if match else None


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Latest[/COLOR]', site.url + 'home/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', '', 'Categories', site.img_cat, page=1)
    site.add_dir('[COLOR hotpink]Actresses[/COLOR]', '', 'Actresses', site.img_cat, page=1)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + '?s=', 'Search', site.img_search)
    List(site.url + 'home/')


@site.register()
def List(url):
    html = utils.getHtml(url, site.url)
    matches = re.findall(
        r'<article class="[^"]*entry[^"]*"[^>]*>.*?<a class="entry-image-link" href="([^"]+)".*?(?:data-src|src)="([^"]+)".*?<h2 class="entry-title"><a class="entry-title-link"[^>]*>([^<]+)</a>',
        html, re.DOTALL | re.IGNORECASE)
    for videopage, img, name in matches:
        name = utils.cleantext(name)
        contextm = utils.performer_context_menu(site.module_name, videopage)
        site.add_download_link(name, videopage, 'Playvid', img, name, noDownload=True, contextm=contextm)
    next_page = _next_page(html)
    if next_page:
        site.add_dir('Next Page...', next_page, 'List', site.img_next)
    utils.eod()


@site.register()
def Categories(url=None, page=1):
    for item in _rest_terms('categories', page):
        if item.get('count', 0) < 1:
            continue
        site.add_dir('{} [COLOR deeppink]{}[/COLOR]'.format(item['name'], item['count']), item['link'], 'List', '')
    if len(_rest_terms('categories', page + 1)) > 0:
        site.add_dir('Next Page ({})'.format(page + 1), '', 'Categories', site.img_next, page=page + 1)
    utils.eod()


@site.register()
def Actresses(url=None, page=1):
    for item in _rest_terms('actress', page):
        if item.get('count', 0) < 1:
            continue
        site.add_dir('{} [COLOR deeppink]{}[/COLOR]'.format(item['name'], item['count']), item['link'], 'List', '')
    if len(_rest_terms('actress', page + 1)) > 0:
        site.add_dir('Next Page ({})'.format(page + 1), '', 'Actresses', site.img_next, page=page + 1)
    utils.eod()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        List(url + urllib_parse.quote_plus(keyword))


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    html = utils.getHtml(url, site.url)
    matches = re.findall(r"playEmbed\('([^']+)'\)", html, re.IGNORECASE)
    if not matches:
        utils.notify('Oh oh', 'No video found')
        return
    hosts = {}
    for link in matches:
        hosts[utils.get_vidhost(link)] = link
    videourl = utils.selector('Select link', hosts) if len(hosts) > 1 else list(hosts.values())[0]
    if not videourl:
        return
    vp.play_from_link_to_resolve(videourl)


@site.register()
def Lookupinfo(url):
    lookup_list = [
        ("Actress", r'href="(https://internetchicks\.com/actress/[^"]+/)"[^>]*>([^<]+)<', ''),
        ("Category", r'href="(https://internetchicks\.com/category/[^"]+/)"[^>]*>([^<]+)<', ''),
    ]
    lookupinfo = utils.LookupInfo('', url, 'internetchicks.List', lookup_list)
    lookupinfo.getinfo()


@site.register()
def OpenModelProfile(url):
    _performer_action(url, 'profile')


@site.register()
def SearchModel(url):
    _performer_action(url, 'search')


@site.register()
def SaveModel(url):
    _performer_action(url, 'save')
