"""
    Cumination
    Copyright (C) 2026 Team Cumination
"""

import html
import re
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite('thepornzone', '[COLOR hotpink]ThePornZone[/COLOR]', 'https://thepornzone.com/', 'https://thepornzone.com/favicon.ico', 'thepornzone')


def _tpz_html(url):
    try:
        response = utils.getHtml(url, site.url, error='raise')
    except Exception:
        if utils.addon.getSetting('fs_enable') == 'true':
            return utils.flaresolve(url, site.url)
        return ''

    if 'window.location.replace(' in response:
        match = re.search(r"window.location.replace\('([^']+)'\)", response, re.IGNORECASE)
        if match:
            challenge_url = html.unescape(match.group(1))
            try:
                response = utils.getHtml(challenge_url, url, error='raise')
            except Exception:
                if utils.addon.getSetting('fs_enable') == 'true':
                    return utils.flaresolve(url, site.url)
                return ''

    if any(domain in response for domain in ('hubgetss.com', 'ext_click_id=')):
        utils.notify('ThePornZone', 'Blocked by challenge/redirect')
        return ''
    return response


def _get_performers(url):
    lookup_list = [
        ("Model", r'/(models/[^"]+)">([^<]+)<', ''),
    ]
    lookupinfo = utils.LookupInfo(site.url, url, 'thepornzone.List', lookup_list)
    return lookupinfo.getitems(labels=utils.PERFORMER_TYPES)


def _performer_action(url, action):
    performer = utils.select_performer(_get_performers(url))
    if not performer:
        utils.notify('Notify', 'No model found for this video')
        return
    if action == 'profile':
        utils.container_update('thepornzone.List', url=performer['url'])
    elif action == 'search':
        utils.container_update('thepornzone.Search', url=site.url + 'search/', keyword=performer['name'])
    else:
        utils.add_keyword_direct(performer['name'])


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url + 'categories/', 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Models[/COLOR]', site.url + 'models/', 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + 'search/', 'Search', site.img_search)
    List(site.url + 'latest-updates/')


@site.register()
def List(url):
    html_data = _tpz_html(url)
    if not html_data:
        return

    delimiter = r'class="thumb thumb_rel'
    if 'class="thumb thumb_rel' in html_data:
        re_videopage = 'href="([^"]+)"'
        re_name = 'title="([^"]+)"'
        re_img = r'data-original="([^"]+)"'
        re_duration = r'class="time">([\d:]+)<'
        re_quality = r'class="quality">([^<]+)<'
        skip = 'class="video-item  private'
    else:
        delimiter = 'class="item  "'
        re_videopage = '<a href="([^"]+)"'
        re_name = 'title="([^"]+)"'
        re_img = 'data-original="([^"]+)"'
        re_duration = '"duration">([^<]+)<'
        re_quality = '"is-hd">([^<]+)<'
        skip = None

    cm = []
    cm.append(('[COLOR deeppink]Lookup info[/COLOR]', 'RunPlugin({})'.format(utils.addon_sys + '?mode=thepornzone.Lookupinfo&url=')))
    cm.extend(utils.performer_context_menu(site.module_name))
    utils.videos_list(site, 'thepornzone.Playvid', html_data, delimiter, re_videopage, re_name, re_img, re_duration=re_duration, re_quality=re_quality, skip=skip, contextm=cm)

    match = re.search(r'''>(\d+)</a>\s+<a class=['"]next['"] .+?data-block-id="([^"]+)"\s+data-parameters="([^"]+)"''', html_data, re.DOTALL | re.IGNORECASE)
    if match:
        lpnr, block_id, params = match.groups()
        npage = params.split(':')[-1]
        params = params.replace(';', '&').replace(':', '=')
        nurl = url.split('?')[0] + '?mode=async&function=get_block&block_id={0}&{1}'.format(block_id, params)
        nurl = nurl.replace('+from_albums', '')
        lastp = '/{}'.format(lpnr) if lpnr else ''
        site.add_dir('[COLOR hotpink]Next Page...[/COLOR] ({})'.format(str(npage) + lastp), nurl, 'List', site.img_next)
    utils.eod()


@site.register()
def Categories(url):
    html_data = _tpz_html(url)
    if not html_data:
        return
    matches = re.findall(r'class="item"\s+href="([^"]+)"\s+title="([^"]+)".+?(?:src="([^"]+)"|data-src="([^"]+)")', html_data, re.DOTALL | re.IGNORECASE)
    for catpage, name, img1, img2 in matches:
        site.add_dir(utils.cleantext(name), catpage, 'List', img1 or img2 or '')
    utils.eod()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        List('{}{}/'.format(url, keyword.replace(' ', '-')))


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    vpage = _tpz_html(url)
    if "kt_player('kt_player'" in vpage:
        vp.progress.update(60, "[CR]kt_player detected[CR]")
        vp.play_from_kt_player(vpage, url)


@site.register()
def Lookupinfo(url):
    lookup_list = [
        ("Model", r'/(models/[^"]+)">([^<]+)<', ''),
        ("Tag", r'/(tags/[^"]+)">([^<]+)<', ''),
    ]
    lookupinfo = utils.LookupInfo(site.url, url, 'thepornzone.List', lookup_list)
    lookupinfo.getinfo()


@site.register()
def OpenModelProfile(url):
    _performer_action(url, 'profile')


@site.register()
def SearchModel(url):
    _performer_action(url, 'search')


@site.register()
def SaveModel(url):
    _performer_action(url, 'save')
