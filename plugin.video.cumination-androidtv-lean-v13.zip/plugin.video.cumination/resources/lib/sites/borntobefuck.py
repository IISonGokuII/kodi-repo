"""
    Cumination
    Copyright (C) 2026 Team Cumination
"""

import json
import re
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite('borntobefuck', '[COLOR hotpink]BornToBeFuck[/COLOR]', 'https://de.borntobefuck.com/', 'https://de.borntobefuck.com/favicon.ico', 'borntobefuck')

XHR_HEADERS = dict(utils.base_hdrs)
XHR_HEADERS.update({'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json'})


class BtbfLookup(utils.LookupInfo):
    def url_constructor(self, url):
        if url.startswith('models/'):
            return '{}{}?type=videos&sort=latest'.format(site.url, url)
        return utils.LookupInfo.url_constructor(self, url)


def _xhr_chunk(url, page=1):
    split = urllib_parse.urlsplit(url)
    params = urllib_parse.parse_qsl(split.query, keep_blank_values=True)
    params = [(key, value) for key, value in params if key not in ('page', 'screen_width')]
    params.append(('page', str(page)))
    params.append(('screen_width', '1200'))
    target = urllib_parse.urlunsplit((split.scheme, split.netloc, split.path, urllib_parse.urlencode(params), ''))
    response = utils.getHtml(target, site.url, headers=XHR_HEADERS)
    try:
        payload = json.loads(response)
        return payload.get('html', ''), payload.get('hasMorePages', False)
    except Exception:
        return response, 'id="load-more"' in response


def _get_performers(url):
    lookup_list = [
        ("Model", r'href="(https://de\.borntobefuck\.com/models/[^"]+)"[^>]*class="active-video-channel[^"]*"[^>]*>.*?alt="([^"]+) Borntobefuck"', ''),
    ]
    lookupinfo = BtbfLookup('', url, 'borntobefuck.List', lookup_list)
    return lookupinfo.getitems(labels=utils.PERFORMER_TYPES)


def _performer_action(url, action):
    performer = utils.select_performer(_get_performers(url))
    if not performer:
        utils.notify('Notify', 'No model found for this video')
        return
    if action == 'profile':
        utils.container_update('borntobefuck.List', url=performer['url'])
    elif action == 'search':
        utils.container_update('borntobefuck.Search', url=site.url + 'suche/ergebnisse?sort=latest&type=videos&search=', keyword=performer['name'])
    else:
        utils.add_keyword_direct(performer['name'])


def _add_next_page(url, mode, page, has_more):
    if has_more:
        site.add_dir('Next Page ({})'.format(page + 1), url, mode, site.img_next, page=page + 1)


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Latest[/COLOR]', site.url + 'videos?sort=trending', 'List', site.img_cat, page=1)
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url + 'kategorien?sort=mostWatched', 'Categories', site.img_cat, page=1)
    site.add_dir('[COLOR hotpink]Countries[/COLOR]', site.url, 'Countries', site.img_cat)
    site.add_dir('[COLOR hotpink]Models[/COLOR]', site.url + 'models?sort=random', 'Models', site.img_cat, page=1)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + 'suche/ergebnisse?sort=latest&type=videos&search=', 'Search', site.img_search)
    List(site.url + 'videos?sort=trending', page=1)


@site.register()
def List(url, page=1):
    html, has_more = _xhr_chunk(url, page)
    matches = re.findall(
        r'<div class="video ranked">.*?<a href="([^"]+)" class="cardVideo-top-link"[^>]*>.*?<img src="([^"]+)".*?data-duration="([^"]*)".*?<a href="([^"]+)" class="profil channel_avatar_video_card"[^>]*>.*?<h3 class="video-title">([^<]+)</h3>.*?<p class="video-channel channel_name_video_card">([^<]+)</p>',
        html, re.DOTALL | re.IGNORECASE)
    for videopage, img, duration, modelurl, name, model_name in matches:
        name = utils.cleantext(name)
        model_name = utils.cleantext(model_name)
        desc = '{}\n{}'.format(model_name, name)
        contextm = utils.performer_context_menu(site.module_name, videopage)
        site.add_download_link(name, videopage, 'Playvid', img, desc, duration=duration, contextm=contextm)
    _add_next_page(url, 'List', page, has_more)
    utils.eod()


@site.register()
def Categories(url, page=1):
    html, has_more = _xhr_chunk(url, page)
    matches = re.findall(r'<li class="card category">.*?<a href="([^"]+)" class="card-link">.*?<img class="model-image" src="([^"]+)".*?<h3 class="card-title">([^<]+)</h3>', html, re.DOTALL | re.IGNORECASE)
    for caturl, img, name in matches:
        name = utils.cleantext(name)
        site.add_dir(name, caturl + '?sort=latest', 'List', img)
    _add_next_page(url, 'Categories', page, has_more)
    utils.eod()


@site.register()
def Models(url, page=1):
    html, has_more = _xhr_chunk(url, page)
    matches = re.findall(r'<li class="card ranked">.*?<a class="card-link\s*" href="([^"]+)".*?<img class="model-image" src="([^"]+)".*?<h3 class="card-title">([^<]+)</h3>.*?<a class="card-country[^"]*" href="([^"]+)">', html, re.DOTALL | re.IGNORECASE)
    for modelurl, img, name, countryurl in matches:
        name = utils.cleantext(name)
        desc = utils.cleantext(countryurl.rsplit('/', 1)[-1].replace('-', ' '))
        site.add_dir(name, modelurl + '?type=videos&sort=latest', 'List', img, desc=desc)
    _add_next_page(url, 'Models', page, has_more)
    utils.eod()


@site.register()
def Countries(url):
    html = utils.getHtml(site.url, site.url)
    matches = re.findall(r'data-nationality="([^"]+)"[^>]*>\s*<img[^>]+alt="([^"]+)"', html, re.DOTALL | re.IGNORECASE)
    seen = set()
    for nationality_id, name in matches:
        if nationality_id in seen:
            continue
        seen.add(nationality_id)
        name = utils.cleantext(name)
        country_url = '{}videos?sort=trending&nationalityId={}'.format(site.url, nationality_id)
        site.add_dir(name, country_url, 'List', '')
    utils.eod()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        List(url + urllib_parse.quote_plus(keyword), page=1)


@site.register()
def Playvid(url, name, download=None):
    match = re.search(r'/videos/(\d+)', url)
    if not match:
        utils.notify('Oh oh', 'No video found')
        return
    player_url = '{}videos/{}/player?lang=de'.format(site.url, match.group(1))
    player_html = utils.getHtml(player_url, url)
    hls_url = re.search(r'data-hls-url="([^"]+)"', player_html, re.IGNORECASE)
    if not hls_url:
        utils.notify('Oh oh', 'No video found')
        return
    utils.playvid(hls_url.group(1), name, download=download, IA_check='IA')


@site.register()
def OpenModelProfile(url):
    _performer_action(url, 'profile')


@site.register()
def SearchModel(url):
    _performer_action(url, 'search')


@site.register()
def SaveModel(url):
    _performer_action(url, 'save')
